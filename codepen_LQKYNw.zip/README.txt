A Pen created at CodePen.io. You can find this one at https://codepen.io/jimmy20640/pen/LQKYNw.

 